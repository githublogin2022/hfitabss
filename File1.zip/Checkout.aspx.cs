﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.Configuration;

namespace ShoeCare
{
	public partial class Checkout : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        [System.Web.Services.WebMethod]
        public static string PlaceOrder(string FirstName, string LastName, string Address, string Phone, string Email, string Notes) {
            if (HttpContext.Current.Session["intOrderID"] != null)
            {
                string strQuery = "usp_ins_upd_tbl_Order " + HttpContext.Current.Session["intOrderID"];

                if (FirstName == "")
                {
                    strQuery += ",Null";
                }
                else
                {
                    strQuery += ",'" + FirstName + "'";
                }
                if (LastName == "")
                {
                    strQuery += ",Null";
                }
                else
                {
                    strQuery += ",'" + LastName + "'";
                }

                if (Address == "")
                {
                    strQuery += ",Null";
                }
                else
                {
                    strQuery += ",'" + Address + "'";
                }

                if (Phone == "")
                {
                    strQuery += ",Null";
                }
                else
                {
                    strQuery += ",'" + Phone + "'";
                }

                if (Email == "")
                {
                    strQuery += ",Null";
                }
                else
                {
                    strQuery += ",'" + Email + "'";
                }

                if (Notes == "")
                {
                    strQuery += ",Null";
                }
                else
                {
                    strQuery += ",'" + Notes + "'";
                }

                strQuery += ",0,0,0,NULL,NULL,NULL,NULL,NULL";

                Common.ExecuteQuery(strQuery);

                StringBuilder strBody = new StringBuilder();
                strBody.Append("Hi " + FirstName + ",");
                strBody.Append("<ul>");
                strBody.Append(new Checkout().GetOrderSummary());
                strBody.Append("</ul>");

                HttpContext.Current.Session["intOrderID"] = null;


                try
                {
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.To.Add(Email);
                    mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["SMTPUserName"].ToString());
                    mailMessage.Subject = "Order Placed Successfully...";
                    mailMessage.IsBodyHtml = true;
                    
                    mailMessage.Body = strBody.ToString();
                    
                    SmtpClient smtpClient = new SmtpClient();
                    if (ConfigurationManager.AppSettings["SMTPUserName"].ToString() != ""){
                        smtpClient.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["SMTPUserName"].ToString(), ConfigurationManager.AppSettings["SMTPPassword"].ToString());
                        }
                    smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPSSL"]);
                    smtpClient.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SMTPPort"]);
                    smtpClient.Host = Convert.ToString(ConfigurationManager.AppSettings["SMTPServer"]);
                    smtpClient.Send(mailMessage);
                    return "E-mail sent!";
                }
                catch (Exception ex)
                {
                    return "Could not send the e-mail - error: " + ex.Message;
                }

            }



            return "Order Placed Successfully";
        }

        public string GetOrderSummary()
        {
            StringBuilder strHTML = new StringBuilder();
            Double fltTotal = 0;
            if (HttpContext.Current.Session["intOrderID"] != null)
            {
                DataSet ds = Common.GetData("usp_sel_tbl_OrderSummary " + HttpContext.Current.Session["intOrderID"]);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    fltTotal += Convert.ToDouble(ds.Tables[0].Rows[i]["ProductPrice"]);
                    strHTML.Append("<li>" + ds.Tables[0].Rows[i]["ShoeName"].ToString() + " (" + ds.Tables[0].Rows[i]["ServiceName"].ToString() + ")" + " <span>Rs." + ds.Tables[0].Rows[i]["ProductPrice"].ToString() + "</span></li>");
                }

                strHTML.Append("<li class='order-total'>Order Total <span>Rs." + fltTotal + "</span></li>");
            }
            return strHTML.ToString();
        }
	}


}