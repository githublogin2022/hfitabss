﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Common.ExecuteQuery("usp_upd_tbl_AllMember");
            }
            DataTable ds = Common.GetData("usp_sel_tbl_AllMember");
            StringBuilder strHTML = new StringBuilder();

        }

        [System.Web.Services.WebMethod]
        public static string PickupConfirm(string ID, string Email, string Name)
        {
            string strBody;
            string today = DateTime.Today.ToString("MM/dd/yyyy");
            string query = "Update tbl_Order set IsPicked = 1, DateofPicked = " + today + " where OrderID = " + Convert.ToInt32(ID);
            Common.ExecuteQuery(query);
            try
            {

                MailMessage mailMessage = new MailMessage();
                mailMessage.To.Add(Email);
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["SMTPUserName"].ToString());
                mailMessage.Subject = "Order Picked up Successfully...";
                mailMessage.IsBodyHtml = true;
                strBody = "Hi " + Name + ",<br>";
                strBody = strBody + "Your Order has been picked up Successfully and will be deliver before " + Convert.ToDateTime(today).AddDays(3).ToShortDateString();
                mailMessage.Body = strBody;

                SmtpClient smtpClient = new SmtpClient();
                if (ConfigurationManager.AppSettings["SMTPUserName"].ToString() != "")
                {
                    smtpClient.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["SMTPUserName"].ToString(), ConfigurationManager.AppSettings["SMTPPassword"].ToString());
                }
                smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPSSL"]);
                smtpClient.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SMTPPort"]);
                smtpClient.Host = Convert.ToString(ConfigurationManager.AppSettings["SMTPServer"]);
                smtpClient.Send(mailMessage);
                return "Pickup E-mail sent!";
            }
            catch (Exception ex)
            {
                return "Could not send the e-mail - error: " + ex.Message;
            }
        }


        [System.Web.Services.WebMethod]
        public static string Ordercompleted(string ID, string Email, string Name)
        {
            string strBody;
            string today = DateTime.Today.ToString("MM/dd/yyyy");
            string query = "Update tbl_Order set IsCompleted = 1, DateofCompletion = " + today + " where OrderID = " + Convert.ToInt32(ID);
            Common.ExecuteQuery(query);
            try
            {

                MailMessage mailMessage = new MailMessage();
                mailMessage.To.Add(Email);
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["SMTPUserName"].ToString());
                mailMessage.Subject = "Order Delivered Successful";
                mailMessage.IsBodyHtml = true;
                strBody = "Hi " + Name + ",<br>";
                strBody = strBody + "We have delivered your order successfully. Please revert us back with your feedback";
                mailMessage.Body = strBody;

                SmtpClient smtpClient = new SmtpClient();
                if (ConfigurationManager.AppSettings["SMTPUserName"].ToString() != "")
                {
                    smtpClient.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["SMTPUserName"].ToString(), ConfigurationManager.AppSettings["SMTPPassword"].ToString());
                }
                smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPSSL"]);
                smtpClient.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SMTPPort"]);
                smtpClient.Host = Convert.ToString(ConfigurationManager.AppSettings["SMTPServer"]);
                smtpClient.Send(mailMessage);
                return "Order Delivered E-mail sent!";
            }
            catch (Exception ex)
            {
                return "Could not send the e-mail - error: " + ex.Message;
            }
        }
    }
}