


IF EXISTS (SELECT 1 FROM dbo.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[usp_ins_upd_tbl_Order]') 
	   AND OBJECTPROPERTY(ID, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].usp_ins_upd_tbl_Order
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE [dbo].[usp_ins_upd_tbl_Order]
/*
Project Name     	:	
Procedure Name		:	[usp_ins_upd_tbl_Order]
Purpose          	:	
Description      	:	
i/p param.		:	
o/i param.		:
Assumptions      	:	None.
Dependencies     	:	None.
Author           	:	Vaijat K
Created          	:	18/11/2017
Reviewed         	:	
Revisions        	:	
*/

--@int INT
@UniqueID int					 = Null
,@FirstName 		nvarchar(50)	 = Null
,@LastName			nvarchar(50)	 = Null
,@Address			nvarchar(500)	 = Null
,@Phone				nvarchar(50)	 = Null
,@EmailAddress		nvarchar(50)	 = Null
,@Notes				nvarchar(2000)	 = Null
,@IsPicked			int				 = Null
,@IsCompleted		int				 = Null
,@IsDelivered		int				 = Null
,@DateofPickup      DATETIME         = Null
,@DateofCompletion	DATETIME		 = Null
,@DateofDelivery	DATETIME		 = Null
,@PickedBy			nvarchar(500)	 = Null
,@DeliveredBy		nvarchar(500)	 = Null
AS
BEGIN

	SET NOCOUNT ON

	/*Declaration and initialization*/

	DECLARE @intUniqueID INT
	/*sql code */	
IF (@UniqueID is NULL)
BEGIN
	INSERT INTO tbl_Order(
		FirstName
		,LastName
		,Address
		,Phone
		,EmailAddress
		,Notes
		,IsPicked
		,IsCompleted
		,IsDelivered
		,DateofPicked
		,DateofCompletion
		,DateofDelivery
		,PickedBy
		,DeliveredBy
	)

	VALUES
	(
		@FirstName
		,@LastName
		,@Address
		,@Phone
		,@EmailAddress
		,@Notes
		,@IsPicked
		,@IsCompleted
		,@IsDelivered
		,@DateofPickup
		,@DateofCompletion
		,@DateofDelivery
		,@PickedBy
		,@DeliveredBy
	)

	SELECT @intUniqueID = SCOPE_IDENTITY()
END
ELSE
BEGIN
	UPDATE tbl_Order
	SET 
		FirstName = @FirstName
		,LastName = @LastName
		,Address = @Address
		,Phone = @Phone
		,EmailAddress = @EmailAddress
		,Notes = @Notes
		,IsPicked=@PickedBy
		,IsCompleted = @IsCompleted
		,IsDelivered = @IsDelivered
		,DateofPicked = @DateofPickup
		,DateofCompletion = @DateofCompletion
		,DateofDelivery = @DateofDelivery
		,PickedBy = @PickedBy
		,DeliveredBy = @DeliveredBy
		WHERE
		OrderID = @UniqueID

		SELECT @intUniqueID = @UniqueID
END
		SELECT @intUniqueID As UniqueID

	/*cleaning*/

SET NOCOUNT OFF
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
