


IF EXISTS (SELECT 1 FROM dbo.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[usp_sel_tbl_AllMember]') 
	   AND OBJECTPROPERTY(ID, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[usp_sel_tbl_AllMember]
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE [dbo].[usp_sel_tbl_AllMember]
/*
Project Name     	:	
Procedure Name		:	[usp_sel_tbl_AllMember]
Purpose          	:	
Description      	:	
i/p param.		:	
o/i param.		:
Assumptions      	:	None.
Dependencies     	:	None.
Author           	:	Ankit P
Created          	:	16/01/2022
Reviewed         	:	
Revisions        	:	
*/

AS
BEGIN

	SET NOCOUNT ON

	/*Declaration and initialization*/
		SELECT tM.FirstName + tM.LastName As FullName,EmailAddress, PhoneNumber,Age,Active_Inactive_cd,Active_Inactive_Desc  
		From tMember tM

	/*cleaning*/

SET NOCOUNT OFF
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
