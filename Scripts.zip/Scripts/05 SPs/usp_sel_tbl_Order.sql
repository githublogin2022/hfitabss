IF EXISTS (SELECT 1 FROM dbo.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[usp_sel_tbl_Order]') 
	   AND OBJECTPROPERTY(ID, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[usp_sel_tbl_Order]
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE [dbo].[usp_sel_tbl_Order]
/*
Project Name     	:	
Procedure Name		:	[usp_sel_tbl_Order] 1,'1,2','1,2'
Purpose          	:	
Description      	:	
i/p param.		:	
o/i param.		:
Assumptions      	:	None.
Dependencies     	:	None.
Author           	:	Ankit P
Created          	:	30/11/2017
Reviewed         	:	
Revisions        	:	
*/

AS
BEGIN

	SET NOCOUNT ON

	/*Declaration and initialization*/
	SELECT tbl_Order.OrderID,tbl_Order.FirstName,tbl_Order.LastName,tbl_Order.EmailAddress,tbl_Order.Address,tbl_Order.IsCompleted,tbl_Order.IsPicked,
		  STUFF( (SELECT ',' + tbl_ShoeType.ShoeType
		    FROM tbl_OrderSummary Left JOIN tbl_ShoeType
		    ON tbl_OrderSummary.ShoeType = tbl_ShoeType.ID
		    FOR XML PATH('')), 1,1, '') [ShoeType],

			 STUFF( (SELECT ',' + tbl_Services.Service
		    FROM tbl_OrderSummary Left JOIN tbl_Services
		    ON tbl_OrderSummary.Service = tbl_Services.Id
		    FOR XML PATH('')), 1,1, '') [Service]
		From 
		tbl_Order
	/*cleaning*/

SET NOCOUNT OFF
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO