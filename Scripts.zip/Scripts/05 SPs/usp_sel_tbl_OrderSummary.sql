


IF EXISTS (SELECT 1 FROM dbo.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[usp_sel_tbl_Order]') 
	   AND OBJECTPROPERTY(ID, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[usp_sel_tbl_Order]
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE [dbo].[usp_sel_tbl_Order]
/*
Project Name     	:	
Procedure Name		:	[usp_sel_tbl_Order] 1,'1,2','1,2'
Purpose          	:	
Description      	:	
i/p param.		:	
o/i param.		:
Assumptions      	:	None.
Dependencies     	:	None.
Author           	:	Ankit P
Created          	:	30/11/2017
Reviewed         	:	
Revisions        	:	
*/

AS
BEGIN

	SET NOCOUNT ON

	/*Declaration and initialization*/
		SELECT tbl_OrderSummary.ID,tbl_Order.OrderID,tbl_Order.FirstName,tbl_Order.LastName,tbl_Order.EmailAddress,tbl_OrderSummary.ShoeType,tbl_OrderSummary.Service,tbl_Services.Service as ServiceName,tbl_ShoeType.ShoeType as ShoeName From tbl_OrderSummary
		Left JOIN 
		tbl_Order
		ON
		tbl_OrderSummary.OrderId = tbl_Order.OrderID
		Left Join
		tbl_Services
		ON
		tbl_OrderSummary.Service = tbl_Services.ID
		LEFT JOIN
		tbl_ShoeType
		ON
		tbl_OrderSummary.ShoeType = tbl_ShoeType.ID

	/*cleaning*/

SET NOCOUNT OFF
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
