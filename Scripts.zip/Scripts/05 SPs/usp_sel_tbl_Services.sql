


IF EXISTS (SELECT 1 FROM dbo.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[usp_sel_tbl_Services]') 
	   AND OBJECTPROPERTY(ID, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[usp_sel_tbl_Services]
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE [dbo].[usp_sel_tbl_Services]
/*
Project Name     	:	
Procedure Name		:	[[usp_sel_tbl_Services]] 1,'1,2','1,2'
Purpose          	:	
Description      	:	
i/p param.		:	
o/i param.		:
Assumptions      	:	None.
Dependencies     	:	None.
Author           	:	Vaijat K
Created          	:	18/11/2017
Reviewed         	:	
Revisions        	:	
*/

--@int INT
AS
BEGIN

	SET NOCOUNT ON

	/*Declaration and initialization*/
		SELECT * From [tbl_Services]

	/*cleaning*/

SET NOCOUNT OFF
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
