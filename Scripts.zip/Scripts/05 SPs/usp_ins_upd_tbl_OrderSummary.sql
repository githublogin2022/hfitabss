


IF EXISTS (SELECT 1 FROM dbo.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[usp_ins_upd_tbl_OrderSummary]') 
	   AND OBJECTPROPERTY(ID, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].usp_ins_upd_tbl_OrderSummary
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE [dbo].[usp_ins_upd_tbl_OrderSummary]
/*
Project Name     	:	
Procedure Name		:	usp_ins_upd_tbl_OrderSummary 1,'1,2','1,2'
Purpose          	:	
Description      	:	
i/p param.		:	
o/i param.		:
Assumptions      	:	None.
Dependencies     	:	None.
Author           	:	Vaijat K
Created          	:	18/11/2017
Reviewed         	:	
Revisions        	:	
*/

--@int INT
@OrderId int= Null
,@ShoeType varchar(5000)
,@Service varchar(5000)
AS
BEGIN

	SET NOCOUNT ON

	/*Declaration and initialization*/

Declare @delimiter As Varchar(1)=','
Declare @Temp as Table ( item varchar(100),item1 varchar(100))
Declare @i as int=0
Declare @j as int=0
Set @j = (Len(@ShoeType) - len(REPLACE(@ShoeType,@delimiter,'')))
While @i  < = @j
Begin
  if @i  < @j
  Begin
      Insert into @Temp 
      Values(SUBSTRING(@ShoeType,1,Charindex(@delimiter,@ShoeType,1)-1),SUBSTRING(@Service,1,Charindex(@delimiter,@Service,1)-1))
      set @ShoeType = right(@ShoeType,(len(@ShoeType)- Charindex(@delimiter,@ShoeType,1)))
	  set @Service = right(@Service,(len(@Service)- Charindex(@delimiter,@Service,1)))
	  
  End
  Else
  Begin
     Insert into @Temp Values(@ShoeType,@Service)
  End

 Set @i = @i + 1
End

	DELETE FROM tbl_OrderSummary WHERE OrderId = @OrderId
	INSERT INTO tbl_OrderSummary
		SELECT @OrderId,Item,Item1,NUll From @Temp		

	/*cleaning*/

SET NOCOUNT OFF
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
